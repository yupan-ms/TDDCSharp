﻿namespace Uqs.AppointmentBooking.Contract;

public record AvailableEmployees(Employee[] Employees);