﻿namespace Uqs.AppointmentBooking.Contract;

public record Employee(int EmployeeId, string Name);