﻿namespace Uqs.AppointmentBooking.Contract;

public record AvailableSlots(DaySlots[] DaysSlots);