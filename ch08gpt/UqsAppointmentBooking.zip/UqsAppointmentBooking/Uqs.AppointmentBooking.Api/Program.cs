using System;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Uqs.AppointmentBooking.Contract;
using Uqs.AppointmentBooking.Domain;
using Uqs.AppointmentBooking.Domain.Services;
using Uqs.AppointmentBooking.Infrastructure.Repositories;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options => options.SwaggerDoc("v1", new OpenApiInfo()
{
    Description = "A booking solution that aims to do the following: \n" + 
    " • Market the available hairdressing services. \n" + 
    " • Allow a customer to book an appointment with a specific or a random barber. \n" +
    " • Give barbers a rest between appointments, usually 5 minutes. \n" +
    " • Barbers have various shifts in the shop and they are off work on different days, so the solution should take care of picking free slots based on the availability of barbers. \n" +
    " • Time saving by not having to arrange appointments on the phone or in person. \n",
    Title = "Uqs Appointment Booking Api",
    Version = "v1",
    Contact = new OpenApiContact()
    {
        Name = "Author",
        Url = new Uri("https://bing.com")
    }
}));

builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    var path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
    options.UseSqlite(String.Format("Data Source={0}", Path.Join(path, "AppointmentBooking.db")));
});

// Add services to the container.
builder.Services.AddScoped<INowService, NowService>();
builder.Services.AddScoped<IServicesService, ServicesService>();
builder.Services.AddScoped<IEmployeesService, EmployeesService>();
builder.Services.AddScoped<ISlotsService, SlotsService>();

builder.Services.Configure<ApplicationSettings>(builder.Configuration.GetSection(nameof(ApplicationSettings)));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
        options.RoutePrefix = string.Empty;
    });
}

app.MapGet("/", () => "Hello World!")
.WithName("Hello")
.WithOpenApi();

app.MapGet("/employees", GetAvailableEmployees)
.Produces<AvailableEmployees>()
.WithOpenApi();

app.MapGet("/services/{id}", GetService)
.Produces<Service>()
.WithOpenApi();

app.MapGet("/services", GetAvailableServices)
.Produces<AvailableServices>()
.WithOpenApi();

app.MapGet("/slots/{serviceId}/{employeeId}", GetAvailableSlots)
.Produces<AvailableSlots>()
.WithOpenApi();


app.Run();

//[HttpGet]
static async Task<IResult> GetAvailableEmployees(IEmployeesService employeesService)
{
    throw new NotImplementedException();
}

//[HttpGet]
static async Task<IResult> GetAvailableServices(IServicesService servicesService)
{
    throw new NotImplementedException();
}

//[HttpGet("{serviceId:int}")]
static async Task<IResult> GetService(int id, IServicesService servicesService)
{
    throw new NotImplementedException();
}

//[HttpGet]
static async Task<IResult> GetAvailableSlots(int serviceId, int? employeeId, ISlotsService slotsService)
{
    throw new NotImplementedException();
}