﻿namespace Uqs.AppointmentBooking.Domain.Report;

public record DaySlots(DateTime Day, DateTime[] Times);