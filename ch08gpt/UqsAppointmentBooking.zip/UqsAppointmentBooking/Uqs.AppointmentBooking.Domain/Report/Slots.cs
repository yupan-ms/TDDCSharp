﻿namespace Uqs.AppointmentBooking.Domain.Report;

public record Slots(DaySlots[] DaysSlots);