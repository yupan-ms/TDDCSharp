﻿namespace Uqs.AppointmentBooking.Domain;

public interface IEntity
{
    public string? Id { get; set; }
}
